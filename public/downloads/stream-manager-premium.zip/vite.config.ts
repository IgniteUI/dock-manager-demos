import { defineConfig } from 'vite';

export default defineConfig({
    base: './',
    resolve: {
        alias: {
            'igniteui-theming': new URL('./node_modules/igniteui-theming', import.meta.url).pathname,
        },
    },
    css: {
        preprocessorOptions: {
            scss: {
                includePaths: ["node_modules"]
            }
        }
    },
    server: {
        port: 3000,
        host: true,
        watch: {
            usePolling: true
        }
    },
    build: {
        rollupOptions: {
            output: {
                assetFileNames: 'assets/[name]-[hash][extname]',
                chunkFileNames: 'assets/[name]-[hash].js',
                entryFileNames: 'assets/[name]-[hash].js'
            }
        }
    }
});
