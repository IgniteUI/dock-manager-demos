# stream-manager Project (PREMIUM Version)

This project was downloaded from the Dock Manager Demos.

## Version Information
- Version: PREMIUM
- Dock Manager Package: @infragistics/igniteui-dockmanager (Premium) ^1.16.1

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Open your browser to http://localhost:3000

## Project Stack

- TypeScript 5.x
- Lit 3.x
- Vite
- Ignite UI Dock Manager (Premium Edition)

## Premium Features
Includes access to all premium features of the Ignite UI Dock Manager.

## Support

For questions or issues, please visit the Infragistics website.

---
Generated on 2025-08-26T07:26:22.472Z
