# stream-manager Project (COMMUNITY Version)

This project was downloaded from the Dock Manager Demos.

## Version Information
- Version: COMMUNITY
- Dock Manager Package: igniteui-dockmanager (Community) ^1.16.1

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Open your browser to http://localhost:3000

## Project Stack

- TypeScript 5.x
- Lit 3.x
- Vite
- Ignite UI Dock Manager (Community Edition)

## Community Version
This is the community version with basic dock manager functionality.


## Support

For questions or issues, please visit the Infragistics website.

---
Generated on 2025-08-22T13:06:21.148Z
